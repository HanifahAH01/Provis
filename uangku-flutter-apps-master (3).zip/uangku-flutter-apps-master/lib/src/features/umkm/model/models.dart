export 'investor.dart';
