import 'dart:ui';

/* COLOR */
const primaryColor = Color(0xFF57C5B6);
const secondaryColor = Color(0xFF159895);
const warnaKetiga = Color(0xFF1A5F7A);
const warnaKeempat = Color(0xFF002B5B);
